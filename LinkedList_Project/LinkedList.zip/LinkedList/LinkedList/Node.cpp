//
//  Node.cpp
//  LinkedList
//
//  Created by Zizhen Chen on 4/26/17.
//  Copyright © 2017 Zizhen Chen. All rights reserved.
//

#include "Node.h"

Node::Node(char datum):datum{datum}{}
