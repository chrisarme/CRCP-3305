class DallasHall
{
private:
	//nothing?
public:
	void draw();
};